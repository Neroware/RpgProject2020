Aloha!
Thanks for downloading this debug build of "Project 2020"! (It's a working title)

1.) CONTROLS
Currently, only keyboard is supported, however I'm planning to add controller support.
Action Button: D
Return Button: S
Inventory: A
Deep Interaction: W (currently not used)
Movement: Arrow Keys
Exit Game: Escape

2.) DISCLAIMER
This game is NOT finished! It's just a debug build! This means there still can be bugs.

3.) TELL ME ABOUT THE EXPERIENCE
I'm still in a very early state of the game. It would be great if you told me how you think 
about this project and what should be better, what has to be better and what can be better.
Your opinion is important to me! Just remember: I only accept constructive critisism. 
You have to tell me what specifically wasn't that good so I can work on it to improve my project.

4.) CREDITS
Chief Programmer: The Great Nero (YT-Channel: https://www.youtube.com/channel/UCPEsDMd9W6qJwaMhJhkUFAg)
Version PreAlpha1.0 Debug Build

Enjoy this intro of the game and most important: Have fun testing around!

